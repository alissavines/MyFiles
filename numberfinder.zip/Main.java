public class Main {
    public static void main(String[] args) {
        int[][] matrix = {{0, 6, 9, 22, 25, 47}, {3, 11, 19, 2, 4, 49}, {13, 18, 29, 42, 52, 69}, {16, 31, 51, 55, 67, 75},
                {34, 38, 57, 65, 77, 89}, {61, 62, 82, 85, 97, 98}};
        int num = 15, temp = 0;
        int n = matrix.length, row = 0, col = n - 1;


        for (int i = 0; i < matrix.length; i++) {
            for (int k = 0; k < matrix.length; k++) {
                if (matrix[i][k] == 57) {
                    System.out.println("57 is located in " + i + " row in " + k + " column");
                }
            }
        }
        while(row < n && col >= 0){
                    if(matrix[row][col] == 57){
                        System.out.println("57 is located at row: "+ row + " and col: "+ col);
                        break;
                    }
                    else if (matrix[row][col]>57) {
                        col--;
                    }
                    else{
                        row++;
                    }
        }
    }
}